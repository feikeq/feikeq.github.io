#!/bin/sh
cd ./csgoserver
echo "Downloading Plugins"
rm -f csgowarmodpluginupdate.tar.gz
wget http://csgo.fk68.net/plugins/csgowarmodpluginupdate.tar.gz
sleep 2s
sleep 1s
echo "[ oK ]"
sudo tar  -zxvf csgowarmodpluginupdate.tar.gz
sleep 3s
cd ..